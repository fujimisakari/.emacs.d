#include <fstream.h>
#include "Char.h"

typedef enum charcode_ {
    HIRA,
    KATA,
    KANJI,
    SEP,
    ETC
} CharCode;

int main(void)
{
    CharStr x(5000);
    char c;
    int i, cx;
    CharCode code, new_code;
    
    code = SEP;
    while (1) {
	cin >> x;
	if (cin.eof()) break;
	for (i = 0; i < x.length(); i++) {
	    cx = x[i].integer();
	    if (cx == 0xa1bc)
		new_code = code;
	    else if (is_kanaH(cx)) {
		new_code = HIRA;
	    } else if (is_kanaK(cx)) {
		new_code = KATA;
	    } else if (is_space(cx) || is_kakko(cx) || is_kokka(cx) ||
		       is_TEN(cx) || cx == 0x2c00) {
		new_code = SEP;
	    } else if (is_EUC(cx)) {
		new_code = KANJI;
	    } else {
		new_code = ETC;
	    }
	    if (code != new_code) {
		if (code != SEP) cout << endl;
		code = new_code;
	    }
	    if (code != SEP) cout << x[i];
	}
    }

    return 0;
}
