#include <fstream.h>
#include "Char.h"

/*
void Char::gen_code(void)
{
    // | . . | | . . | | . . | | . . |
    //               a s ( ) t - K k h
    codev = 0x0000;
    if (is_EUC(C.d)) {
	codev |= C_EUC;
	if (C.d == 0xA1BC) {
	    codev |= 0x0008;
	} else if (is_kanaH(C.d)) {
	    codev |= 0x0001;
	} else if (is_kanaK(C.d)) {
	    codev |= 0x0002;
	} else {
	    codev |= 0x0004;
	}
    } else {
	codev |= C_ASCII;
	codev |= 0x0100;
    }
    if (is_space(C.d)) {
	codev |= 0x0080;
    } else if (is_TEN(C.d)) {
	codev |= 0x0010;
    } else if (is_kakko(C.d)) {
	codev |= 0x0040;
    } else if (is_kokka(C.d)) {
	codev |= 0x0020;
    }
}
*/

istream& operator>>(istream& in, Char& x)
{
    in.get(x.C.c.h);
    if (is_EUC(x.C.d)) {
	in.get(x.C.c.l);
    } else {
	x.C.c.l = '\0';
    }
//    x.gen_code();
    return(in);
}

ostream& operator<<(ostream& out, Char& x)
{
    cout.put(x.C.c.h);
    if (x.C.c.l) {
	cout.put(x.C.c.l);
    }
    return out;
}

Char& Char::operator=(char in)
{
    this->C.c.h = in;
    this->C.c.l = '\0';
//    gen_code();
    return(*this);
}

Char& Char::operator=(char* in)
{
    this->C.c.h = *in;
    if (is_EUC_pref(*in)) {
	this->C.c.l = *(in + 1);
    } else {
	this->C.c.l = '\0';
    }
//    gen_code();
    return(*this);
}

Char& Char::operator=(Char& in)
{
    this->C.d = in.C.d;
//    codev = in.codev;
    return(*this);
}


CharStr& CharStr::operator=(char* s)
{
    int i;
    for (i = 0; i < max; i++) {
	*(str + i) = s;
	if (*s == '\n') break;
	if (*s == '\0') break;
	if (is_EUC_pref(*s)) {
	    s += 2;
	} else {
	    s++;
	}
    }
    len = i;
    *(str + len) = '\0';
    
    return *this;
}
istream& operator>>(istream& in, CharStr& x)
{
    int i;
    for (i = 0; i < x.max; i++) {
	in >> *(x.str+i);
	if (in.eof()) break;
	if (*(x.str+i) == '\n') break;
    }
    x.len = i;
    *(x.str + x.len) = '\0';
    
    return in;
}
ostream& operator<<(ostream& out, CharStr& x)
{
    for (int i = 0; i < x.len; i++) {
	out << *(x.str + i);
    }
    return out;
}


/*
int main(void)
{
    CharStr x(1000);
    char c[100];
    
    while (1) {
	cin >> x;
	if (cin.eof()) break;
	cout << x << endl;
    }

    return 0;
}
*/
