#-*- perl -*-
package DID;
require 5.000;
#======================================================================
#                                          Perl Module version
#
#                                            written by T.Nakayama
#======================================================================
require DynaLoader;
@ISA = qw(DynaLoader);
$SUF_DID_MAX = -1;

# ���󥹥ȥ饯��
sub new {
    my ($class,$didfile) = @_;
    my $self = {};
    bless $self, $class;

    if (++$SUF_DID_MAX >= 256) { return undef; }

    $self->{'id'} = $SUF_DID_MAX;

    $self->{'didfile'} = $didfile;
    if (suf_opendid($SUF_DID_MAX, $didfile) <= 0) {
	return undef;
    } else {
	return $self;
    }
}
# �����ե�����κƥ����ץ�
sub reopen {
    my ($self,$didfile) = @_;

    if (!(defined $didfile)) {$didfile = $self->{'didfile'}}
    $self->{'didfile'} = $didfile;
    
    if (suf_opendid($self->{'id'}, $didfile)) {
	return 1;
    } else {
	return 0;
    }
}
# �����ե�������Ĥ���
sub close {
    my $self = shift;

    suf_closedid($self->{'id'});
}
# ����
sub didsearch {
    my ($self, $target) = @_;
    
    return suf_didsearch($self->{'id'}, $target);
}
# 
sub did_size {
    my ($self) = @_;
    return suf_did_size($self->{'id'});
}


bootstrap DID;
1;
