#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <fcntl.h>


char* text;
size_t open_file(char *fname);

main(int argc, char *argv[])
{

  char *pat, *fname;
  FILE *in_file;
  long text_size;
  long i;
  int pat_length;

  if (argc != 3){fprintf(stderr,"argument error\n"); exit(1);}
  pat = argv[1];
  fname = argv[2];
  pat_length = strlen(pat);

  /* �ե�����򳫤� */
  text_size = open_file(fname);
  
  /* ����(scan) */

  for(i = 0; i < text_size; i++){
    

  }


}


size_t open_file(char *fname)
{
  struct stat stat_buf;
  int fd;
  size_t N;

  if ((fd = open(fname, O_RDONLY)) < 0){ /* ���ϥե����� */
    fprintf(stderr,"ERROR: file open erroe. [%s]\n", fname);
    exit(8);
  }

  (void)fstat(fd, &stat_buf);
  N = (size_t)stat_buf.st_size;

  if((text = mmap((caddr_t)0, N, PROT_READ, MAP_SHARED, fd, 0))
     == (caddr_t)-1){
    fprintf(stderr,"ERROR: file mapping error. [%s]\n", fname);
    exit(1);
  }
  return N;
}

