#ifndef __strop__
#define __strop__

char* str_append (char* prefix, char* suffix);

#endif
