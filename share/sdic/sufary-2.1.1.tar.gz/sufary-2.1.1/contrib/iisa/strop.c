#include <stdio.h>
#include "strop.h"

char* str_append (char* prefix, char* suffix)
{
    int lenp, lens;
    char* ret;

    lenp = strlen(prefix);
    lens = strlen(suffix);
    if ((ret = (char*)malloc(sizeof(char)*(lenp+lens+1))) == NULL) {
	fprintf(stderr, "memory allocation error\n");
	exit(1);
    }

    strcpy(ret, prefix);
    strcpy((ret+lenp), suffix);

    return ret;
}
